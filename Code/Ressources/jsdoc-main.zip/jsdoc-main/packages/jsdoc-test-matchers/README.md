# `@jsdoc/test-matchers`

[Jasmine](https://jasmine.github.io/) matchers that JSDoc uses in its tests.
