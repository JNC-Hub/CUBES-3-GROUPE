# `@jsdoc/core`

Core functionality for JSDoc.
