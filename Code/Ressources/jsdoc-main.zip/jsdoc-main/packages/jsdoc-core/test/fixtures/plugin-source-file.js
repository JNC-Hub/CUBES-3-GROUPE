/**
 * @name virtual
 */

const foo = 'bar';

/**
 * @foo bar
 */
const test = 'tada';
