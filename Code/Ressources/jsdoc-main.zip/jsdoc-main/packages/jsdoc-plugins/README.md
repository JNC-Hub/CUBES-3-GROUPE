# `@jsdoc/plugins`

Sample plugins for JSDoc.
