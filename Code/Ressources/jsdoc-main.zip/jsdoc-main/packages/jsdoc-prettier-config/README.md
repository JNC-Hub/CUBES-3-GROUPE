# `@jsdoc/prettier-config`

A Prettier (https://prettier.io/) configuration for JSDoc.
