# `@jsdoc/parse`

Parses, and extracts information from, source code.
