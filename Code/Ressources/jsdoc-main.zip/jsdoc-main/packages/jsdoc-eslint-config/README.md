# `@jsdoc/eslint-config`

Default ESLint configuration for JSDoc packages.
