# `@jsdoc/util`

Utility modules for JSDoc.
