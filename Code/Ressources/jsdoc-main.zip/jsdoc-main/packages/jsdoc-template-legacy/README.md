# `@jsdoc/template-legacy`

Legacy template from JSDoc 3.x.
