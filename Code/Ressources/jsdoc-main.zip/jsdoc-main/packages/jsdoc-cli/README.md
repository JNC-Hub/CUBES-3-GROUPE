# @jsdoc/cli

Command-line tool for JSDoc.

## Installing the package

Using npm:

```shell
npm install --save @jsdoc/cli
```
