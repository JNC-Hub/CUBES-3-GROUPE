# JSDoc CLI tool

This directory contains most of the source files for JSDoc.

Over time, most of the code in this package is being moved into other packages.
