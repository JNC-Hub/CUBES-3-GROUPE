/** @module foo */

/** Bar class. */
class Bar {
    /** Construct a Bar. */
    constructor() {
        /** bar property */
        this.bar = 0;
    }
}

/** Baz class. */
export class Baz {
    /** Construct a Baz. */
    constructor() {
        /** baz property */
        this.baz = 0;
    }
}
