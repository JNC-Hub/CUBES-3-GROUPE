/**
 * My mutator function.
 * @modifies {(foo|bar)}
 */
function mutator(foo, bar) {}
