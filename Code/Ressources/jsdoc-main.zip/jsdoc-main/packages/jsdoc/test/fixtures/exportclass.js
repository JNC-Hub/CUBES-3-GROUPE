/**
 * Foo module
 * @module foo
 */

/** Class description */
export class Bar {
}
