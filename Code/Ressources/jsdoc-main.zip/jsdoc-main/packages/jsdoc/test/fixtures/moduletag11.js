/**
 * Test module.
 * @module foo
 */

/** Test class. */
export class Foo {
    /** Test class constructor. */
    constructor() {}

    /** Test method. */
    testMethod() {}
}
