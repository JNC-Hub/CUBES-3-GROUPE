/**
 * This is an externs file.
 *
 * @externs
 */
