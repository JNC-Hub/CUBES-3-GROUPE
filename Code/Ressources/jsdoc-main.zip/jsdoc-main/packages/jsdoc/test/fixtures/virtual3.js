/** @module connection

/**
 * @param {string} name - The connection name.
 * @constructor module:connection
 *//**
 * @constructor module:connection
 */
module.exports = function() {
    // ...
};
