/**
 * A Polymer class.
 * @polymer
 */
function Foo() {}
