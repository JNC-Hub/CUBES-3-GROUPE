/** @module test */

/** Test class */
export default class Foo {
    /** Test constructor */
    constructor() {}
}
