/**
 * My class.
 *
 * @constructor
 * @unrestricted
 */
function Foo() {}
