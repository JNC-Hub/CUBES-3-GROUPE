define(function () {
    /**
     * @exports mymodule
     * @enum {string}
      */
    var exports = {
        A: 'abc'
    };

    return exports;
});
