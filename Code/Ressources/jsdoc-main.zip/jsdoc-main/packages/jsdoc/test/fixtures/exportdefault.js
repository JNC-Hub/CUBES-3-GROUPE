/** @module test */

/** Test value */
export default 'foo';
