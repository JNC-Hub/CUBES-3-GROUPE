/**
 * My class.
 *
 * @constructor
 * @export
 */
function MyClass() {}

/**
 * My public method.
 *
 * @export
 */
MyClass.prototype.myPublicMethod = function() {};
