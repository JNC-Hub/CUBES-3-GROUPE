/**
 * Public variable.
 *
 * @public {string}
 */
var bar = 'baz';
