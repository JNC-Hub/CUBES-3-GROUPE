/**
 * My structural interface.
 *
 * @record
 */
function MyStructuralInterface() {}
