/** @noalias */
function Foo() {}
