/**
 * ES 2015 class assigned to a const
 */
const Foo = class bar {}
