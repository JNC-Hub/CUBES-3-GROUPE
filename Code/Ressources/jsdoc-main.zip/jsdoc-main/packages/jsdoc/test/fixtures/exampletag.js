/** @example
 * console.log("foo");
 * console.log("bar");
 */
var x;

/** @example
 * console.log("foo");
 * console.log("bar");
 * @example
 * <caption>Example 2</caption>
 * 1 + 2;
 */
var y;
