'use strict';

/** @class */
function Template() {}

Template.constructor = function() {
    /** Render content. */
    this.render = function(data) {};
};
