/** @module foo */

export const Foo = bar(baz => {
})(class {
    qux = () => {}
});
