/**
 * This function is package-private.
 *
 * @package
 */
function foo() {}
