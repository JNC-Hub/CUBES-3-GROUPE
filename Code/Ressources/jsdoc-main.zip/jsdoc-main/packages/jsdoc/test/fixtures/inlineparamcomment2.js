var ns = {
    foo: function(/** @type {string} */ bar = '', /** @type {number} */ ...baz) {}
};
