'use strict';

/** @external foo */
