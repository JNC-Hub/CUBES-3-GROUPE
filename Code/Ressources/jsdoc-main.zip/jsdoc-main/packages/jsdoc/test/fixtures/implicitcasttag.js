function Foo() {}

/**
 * @type {string}
 * @implicitCast
 */
Foo.prototype.bar;
