/**
 * @param {T} t
 * @constructor
 * @template T
 */
function Container(t) {}
