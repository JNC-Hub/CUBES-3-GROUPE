'use strict';

/** @module example */

/** @alias module:example */
class Foo {
    constructor() {}
}
