'use strict';

/**
 * Sample generator function.
 * @function idMaker
 * @generator
 */
