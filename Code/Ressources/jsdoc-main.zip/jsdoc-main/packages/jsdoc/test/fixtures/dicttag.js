/**
 * @constructor
 * @dict
 */
function Foo() {}
