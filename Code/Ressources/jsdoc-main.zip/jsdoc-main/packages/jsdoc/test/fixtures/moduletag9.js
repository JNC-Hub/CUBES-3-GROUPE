/** @module foo */

export * from 'bar';
