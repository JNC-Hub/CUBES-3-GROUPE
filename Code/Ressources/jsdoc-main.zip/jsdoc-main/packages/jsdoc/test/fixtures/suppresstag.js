/**
 * Foo class.
 *
 * @constructor
 * @suppress {deprecated}
 */
function Foo() {}
