/**
 * Foo class.
 *
 * @constructor
 * @struct
 */
function Foo() {}
