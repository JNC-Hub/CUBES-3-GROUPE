/** @module appname */

/**
 * The name of the application.
 * @type {string}
 */
export default 'mixer';
