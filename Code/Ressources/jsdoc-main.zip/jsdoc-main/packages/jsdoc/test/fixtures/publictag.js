/**
 * Public class.
 *
 * @class
 * @public
 */
function Foo() {}
