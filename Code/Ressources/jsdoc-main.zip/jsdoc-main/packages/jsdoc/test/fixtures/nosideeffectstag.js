/**
 * A function that does nothing.
 * @nosideeffects
 */
function doNothing() {}
