/**
 * A namespace.
 * @const
 */
var foo = {};

/** @nocollapse */
foo.bar = true;
