/**
 * Controls whether debugging is enabled.
 *
 * @define {boolean} `true` if enabled, `false` otherwise
 */
var ENABLE_DEBUG = true;
