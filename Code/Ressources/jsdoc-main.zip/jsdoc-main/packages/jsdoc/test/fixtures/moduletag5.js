/**
 * @module module:bookshelf
 */
