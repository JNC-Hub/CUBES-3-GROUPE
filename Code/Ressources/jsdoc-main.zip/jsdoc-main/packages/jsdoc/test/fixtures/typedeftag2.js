/** @typedef {(string|number)} */
calc.NumberLike;
