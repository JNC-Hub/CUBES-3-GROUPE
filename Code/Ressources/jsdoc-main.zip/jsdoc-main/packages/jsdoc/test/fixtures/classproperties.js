/** Sample class. */
class A {
    /** Public property. */
    b = 1;

    /** Private property. */
    #c = 2;

    /** Property with no value assigned to it. */
    d;
}
