const foo = {
    bar: {}
};

/**
 * Baz class.
 */
foo.bar.Baz = class {
    /**
     * Creates a Baz.
     *
     * @param {string=} first - First parameter.
     * @param {string=} second - Second parameter.
     */
    constructor(first, second) {}
};
