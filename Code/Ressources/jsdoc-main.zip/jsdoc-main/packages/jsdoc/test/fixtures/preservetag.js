/** @preserve My cool license goes here. */
var x;
