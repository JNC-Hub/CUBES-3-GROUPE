declare({
    globals: /** @lends */ {

        /** document me */
        'test': function() { },

        /** @namespace */
        'test1': {

            /** document me */
            'test2': function() {  }
        }
    }
});