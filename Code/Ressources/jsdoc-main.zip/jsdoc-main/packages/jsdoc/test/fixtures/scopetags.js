/** (scope tags for global objects do not override globalness hence need a container class)
 * @module scopetags */
/** @inner */
var myInner;

/** @instance */
var myInstance;

/** @static */
var myStatic;
