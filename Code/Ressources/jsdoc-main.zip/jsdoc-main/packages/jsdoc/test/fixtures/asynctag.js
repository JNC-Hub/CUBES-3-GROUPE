/**
 * Asynchronous function.
 *
 * @function foo
 * @async
 */
