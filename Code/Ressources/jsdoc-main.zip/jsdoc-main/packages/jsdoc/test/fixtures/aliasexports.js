/** @module foo */

/**
 * Bar class.
 *
 * @alias module:foo.Bar
 */
class Bar {
    /** Create a Bar. */
    constructor() {}
}

exports.Bar = Bar;
