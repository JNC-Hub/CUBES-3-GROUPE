'use strict';

module.exports = {};

/** @external foo */
